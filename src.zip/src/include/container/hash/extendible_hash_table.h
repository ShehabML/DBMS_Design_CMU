

#pragma once

#include <cstdlib>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include <cassert>
#include <functional>
#include <list>
#include <bitset>
#include <iostream>

#include "container/hash/hash_table.h"
#include "storage/page/page.h"

namespace bustub {

// only support unique key
template <typename K, typename V>
class ExtendibleHashTable : public HashTable<K, V> {
  struct Bucket {
    Bucket() = default;
    explicit Bucket(size_t i, int d) : id(i), depth(d) {}
    std::map<K, V> items;          
    size_t id = 0;                 
    int depth = 0;                 
  };
public:
   
    ExtendibleHashTable(size_t size);
    int GetGlobalDepth() const;

    
    int GetLocalDepth(int bucket_id) const;

    
    int GetNumBuckets() const;

   
    size_t HashKey(const K &key);

    
    bool Find(const K &key, V &value);

    
    void Insert(const K &key, const V &value);

   
    bool Remove(const K &key);

    size_t Size() const { return pair_count_; }

    
    

private:
    mutable std::mutex mutex_;      

    const size_t bucket_size_;    

    int bucket_count_;   

    size_t pair_count_;     

    int depth;              

    std::vector<std::shared_ptr<Bucket>> bucket_;    

    std::shared_ptr<Bucket> split(std::shared_ptr<Bucket> &); 
};

} // namespace bustub
